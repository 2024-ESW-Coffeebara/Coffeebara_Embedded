import cv2
import matplotlib as plt
import numpy as np

img = cv2.imread('image_51.png', cv2.COLOR_BGR2RGB)
img = img[:, :300]
cv2.imshow('test', img)
cv2.waitKey(0)